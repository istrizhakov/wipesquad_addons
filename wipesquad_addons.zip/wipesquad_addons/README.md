# Набор аддонов для рейдов <Wipe Squad>

## Установка

### Автоматическая

Разархивировать архив в корень World of Warcraft, запустить install.bat

### Ручная

 - Разархивировать архив, 
 - удалить из %Wolrd of Warcraft/Interface/Addons аддоны Banana, BigWigs, CthunWarner, Decursive, KLHThreatMeter(если есть),
 - скопировать содержимое из ./wipesquad_addons в директорию %Wolrd of Warcraft/Interface/Addons.