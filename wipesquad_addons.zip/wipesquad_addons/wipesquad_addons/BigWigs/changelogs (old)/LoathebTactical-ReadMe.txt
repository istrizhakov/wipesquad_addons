Big Wigs Loatheb Tactical

Targetted at raid leaders to announce warnings. Not suited to by many people as this is a warning module that broadcasts over raid channel and sends whispers.

This mod can do two things :

1. It announces to raid what consumable to use after doom hits.

2. it setups a group based spore rotation, starting from group 8 and counting down to group 1. It places raid icons on the groups that are in turn to get the spore buff, it sends whispers to all 5 group  members that it is their turn, and it says in raid channel which group should get the spore.

Beerke
www.caelum.ws
Thunderhorn PvE EU

