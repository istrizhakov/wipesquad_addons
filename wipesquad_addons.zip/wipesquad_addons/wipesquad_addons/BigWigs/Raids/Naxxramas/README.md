<b><a href="https://github.com/MOUZU/BigWigs"> Return to the Overview </a></b>

<br \><br \>
# Naxxramas

## Spider Wing
### Anub'Rekhan

### Grand Widow Faerlina

### Maexxna

## Plague Wing
### Noth the Plaguebringer

### Heigan the Unclean

### Loatheb

## Abomination Wing
### Patchwerk

### Grobbulus

### Gluth

### Thaddius

## Death Knight Wing
### Instructor Razuvious

### Gothik the Harvester

### The Four Horsemen

## Frostwyrm Lair
### Sapphiron

### Kel'Thuzad

<br \><br \>
##### Prefix legend
- <b>(100%)</b>  = it's working flawless
- <b>(99%)</b>   = it's working as good as it can be (from my research)
- <b>(QA)</b>    = <b>Q</b>uality <b>A</b>ssurance (need to test its modified state)
- <b>(DG)</b>    = <b>D</b>ata <b>G</b>athering (need to gather more data regarding this matter)
